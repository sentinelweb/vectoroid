/** Automatically generated file. DO NOT MODIFY */
package co.uk.sentinelweb.vectoroid.example.basic;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}