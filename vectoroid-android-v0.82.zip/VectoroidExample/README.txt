Vectoroid Example

This is a simple example to display a drawing.

Just Import into your workspace along with vectoroid-android and build run.

If you are using maven the you need to run 'mvn clean install' in vectoroid-android first.

Then here:
mvn clean install android:deploy

APK is in the target 
