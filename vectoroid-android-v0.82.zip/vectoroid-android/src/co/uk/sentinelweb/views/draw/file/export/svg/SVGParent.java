package co.uk.sentinelweb.views.draw.file.export.svg;

import co.uk.sentinelweb.views.draw.file.SaveFile;

public class SVGParent {
	SaveFile _saveFile;

	public SVGParent(SaveFile _saveFile) {
		super();
		this._saveFile = _saveFile;
	}
	
	
}
