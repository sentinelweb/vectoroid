package co.uk.sentinelweb.vectoroid.explode.app;

import co.uk.sentinelweb.vectoroid.explode.SuprCardsExploderActivity;


public class SuprCardsExploderOpenAppActivity  extends SuprCardsExploderActivity {
    /** Called when the activity is first created. */
   // @Override
   // public void onCreate(Bundle savedInstanceState) {
   //     super.onCreate(savedInstanceState);
   //     setContentView(R.layout.main);
   // }
}