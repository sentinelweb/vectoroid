/** Automatically generated file. DO NOT MODIFY */
package co.uk.sentinelweb.vectoroid.explode;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}