SuprCards Explodr

This is the source for the SuprCards Explodr app. It animates drawings made in SuprCards (of a hello world if SuprCards not installed)

This use the SuprCardsConstants Definition Object : 
see: 

Just Import into your workspace along with vectoroid-android and build run.

If you are using maven the you need to run 'mvn clean install' in vectoroid-android first.

Then here:
mvn clean install

Since this is a real app, this is an Android Lbrary, so I can release it, you'll need to make an app to run it. 
See http://sentinelweb.co.uk for more info.

