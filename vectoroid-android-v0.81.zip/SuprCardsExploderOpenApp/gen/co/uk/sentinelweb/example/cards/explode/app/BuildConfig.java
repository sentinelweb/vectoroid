/** Automatically generated file. DO NOT MODIFY */
package co.uk.sentinelweb.example.cards.explode.app;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}